geert.link icon package
Source: central G-arrow mark isolated from the supplied screenshot.

Folders:
- ios: common iPhone/iPad AppIcon PNG sizes plus 1024x1024
- android: launcher PNGs for mdpi through xxxhdpi plus 512x512 Play Store icon
- web: favicon.ico and PNG icons from 16x16 through 512x512
- geert-link-icon-master-1024.png: transparent master

Note: This package is reconstructed from a raster screenshot, not an original vector asset.
